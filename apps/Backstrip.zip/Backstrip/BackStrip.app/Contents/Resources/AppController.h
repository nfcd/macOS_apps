//
//  AppController.h
//  BackStrip
//
//  Copyright __Nestor Cardozo__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
@class PreferenceController;
@class InspectorController;
@class DocumentationController;

@interface AppController : NSObject {
	PreferenceController *preferenceController;
	InspectorController *inspectorController;
    DocumentationController *documentationController;
}

- (IBAction)showPreferencePanel:(id)sender;
- (IBAction)showInspectorPanel:(id)sender;
- (IBAction)showDocumentation:(id)sender;

@end
