//
//  MyArrayController.h
//  BackStrip
//
//  Copyright __Nestor Cardozo__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface MyArrayController : NSArrayController
{
	IBOutlet NSTableView *unitsTableView;
}
// table view drag and drop support

- (NSTableView *)unitsTableView;
- (BOOL)tableView:(NSTableView *)tv writeRowsWithIndexes:(NSIndexSet *)rowIndexes toPasteboard:(NSPasteboard*)pboard;
- (NSDragOperation)tableView:(NSTableView*)tv validateDrop:(id <NSDraggingInfo>)info 
				 proposedRow:(int)row proposedDropOperation:(NSTableViewDropOperation)op;
- (BOOL)tableView:(NSTableView*)tv acceptDrop:(id <NSDraggingInfo>)info row:(int)row 
	dropOperation:(NSTableViewDropOperation)op;
- (BOOL)readFromPasteboard:(NSPasteboard *)pb;


@end
