//
//  PreferenceController.h
//  BackStrip
//
//  Copyright __Nestor Cardozo__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//declare this keys as extern
extern NSString *BSEmptyDocument;

@interface PreferenceController : NSWindowController 
{
	IBOutlet NSButton *checkbox;
}

-(IBAction)changeNewEmptyDoc:(id)sender;

@end
