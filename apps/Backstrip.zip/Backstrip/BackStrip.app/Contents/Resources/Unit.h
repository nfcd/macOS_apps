//
//  Unit.h
//  BackStrip
//
//  Copyright __Nestor Cardozo__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface Unit : NSObject <NSCoding> {

}

@property (nonatomic,copy) NSString *unitName;
@property (nonatomic) float base;
@property (nonatomic) float ageBase;
@property (nonatomic) float SLBase;
@property (nonatomic) float WDBase;
@property (nonatomic) float top;
@property (nonatomic) float ageTop;
@property (nonatomic) float SLTop;
@property (nonatomic) float WDTop;
@property (nonatomic) float dryDens;
@property (nonatomic) float porCo;
@property (nonatomic) float surfPor;
@property (nonatomic) int theType;

@end
