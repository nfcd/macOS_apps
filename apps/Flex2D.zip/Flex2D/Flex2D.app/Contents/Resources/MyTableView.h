//
//  MyTableView.h
//  Flex2D
//
//  Copyright __Nestor Cardozo__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface MyTableView : NSTableView
{
}
@end
