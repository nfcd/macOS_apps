//
//  PreferenceController.h
//  Flex2D
//
//  Copyright __Nestor Cardozo__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//declare these keys as extern
extern NSString *F2DEmptyDocument;
extern NSString *F2DDrawingLoads;

@interface PreferenceController : NSWindowController 
{
	IBOutlet NSButton *openNewAutomaticCheckbox;
	IBOutlet NSButton *drawLoadsAutomaticCheckbox;
}

-(IBAction)changeOpeningSettings:(id)sender;

@end
