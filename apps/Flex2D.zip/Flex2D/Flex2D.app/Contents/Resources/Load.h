//
//  Load.h
//  Flex2D
//
//  Copyright __Nestor Cardozo__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface Load : NSObject {

}

@property (nonatomic) float xMin;
@property (nonatomic) float xMax;
@property (nonatomic) float height;
@property (nonatomic) float density;
@property (nonatomic) float topoXMin;
@property (nonatomic) float topoXMax;


@end
